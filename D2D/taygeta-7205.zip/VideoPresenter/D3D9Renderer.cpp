// This is the main DLL file.

#include "stdafx.h"

#include "D3D9Renderer.h"

