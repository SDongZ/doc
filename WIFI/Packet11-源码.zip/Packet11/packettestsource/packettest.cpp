/*
	PacketTest Command Line
	Compiled with Windows SDK v6.1

	Description
	This application shows how to construct an 802.11 frame and send it to the
	Packet11 service.

	Author - Ryan Grevious
*/


#include <stdio.h>
#include <stdlib.h>  //for system()
#include "winsock2.h" //for 80211
#include "80211hdr.h"

#define _NDIS_CONTROL_CODE(request,method) \
            CTL_CODE(FILE_DEVICE_PHYSICAL_NETCARD, request, method, FILE_ANY_ACCESS)

//codes 5, 6, 19 will be supported in a later version
#define IOCTL_PACKET11_SET_OID_VALUE          _NDIS_CONTROL_CODE(5, METHOD_BUFFERED)
#define IOCTL_PACKET11_QUERY_OID_VALUE        _NDIS_CONTROL_CODE(6, METHOD_BUFFERED)
#define IOCTL_PACKET11_INSERT_PACKET		_NDIS_CONTROL_CODE(14, METHOD_BUFFERED)
#define IOCTL_PACKET11_GET_BSSID			_NDIS_CONTROL_CODE(19, METHOD_BUFFERED)
#define IOCTL_PACKET11_GET_MAC				_NDIS_CONTROL_CODE(20, METHOD_BUFFERED)


#define MAC_ADDR_LEN  6

#define MAX_LEN 256


CHAR            PacketuioDevice[] = "\\\\.\\\\Packet11";
CHAR *          pPacketuioDevice = &PacketuioDevice[0];


HANDLE
OpenHandle(
    __in __nullterminated CHAR    *pDeviceName
)
{
    DWORD   DesiredAccess;
    DWORD   ShareMode;
    LPSECURITY_ATTRIBUTES   lpSecurityAttributes = NULL;

    DWORD   CreationDistribution;
    DWORD   FlagsAndAttributes;
    HANDLE  Handle;


    DesiredAccess = GENERIC_READ|GENERIC_WRITE;
    ShareMode = 0;
    CreationDistribution = OPEN_EXISTING;
    FlagsAndAttributes = FILE_ATTRIBUTE_NORMAL;

    Handle = CreateFile(
                pDeviceName,
                DesiredAccess,
                ShareMode,
                lpSecurityAttributes,
                CreationDistribution,
                FlagsAndAttributes,
                NULL
                );
    if (Handle == INVALID_HANDLE_VALUE)
    {
        printf("Creating file failed, error %x\n", GetLastError());
        return Handle;
    }


    return (Handle);
}

BOOL IORequest(HANDLE Handle,
			DWORD controlcode,
			PUCHAR input,
			DWORD inputsize,
			PUCHAR output,
			DWORD outputsize
			)
{

		DWORD   BytesReturned = 0;
		BOOL status;

	    status = (DeviceIoControl(
	                Handle,
	                controlcode,
	                input,
	                inputsize,
	                output,
	                outputsize,
	                &BytesReturned,
                	NULL));

        if(GetLastError() != 0)
       		printf("error %d , bytes returned %d \n",GetLastError(), BytesReturned);

        //Packet11 returns ERROR_NETWORK_ACCESS_DENIED if the user packet could not be allocated
        if(GetLastError() == ERROR_NETWORK_ACCESS_DENIED) printf("Waiting for network resources \n");

        return status;

}


void * CreatePacket(
			DOT11_MGMT_SUBTYPE subtype,
			PUCHAR Source,
			PUCHAR Dest,
			PUCHAR Bssid,
			ULONG packetsize
			)


{

    PDOT11_MGMT_HEADER			pMgmtHeader = NULL;
    PDOT11_PROBE_REQUEST		pProbeRequest = NULL;
    PDOT11_INFO_ELEMENT			pInfoElement = NULL;
    PDOT11_BASIC_RATE			pBasicRate = NULL;
    PDOT11_EXT_RATE				pExtRate = NULL;
    PVOID 						DataBuffer = NULL;


	if(Source == NULL || Dest == NULL || Bssid == NULL){
		printf("CreatePacket ==> null mac address \n");
		return DataBuffer;
	}

	DataBuffer = malloc(packetsize);

	pMgmtHeader = (PDOT11_MGMT_HEADER)(PUCHAR)DataBuffer;
	pMgmtHeader->FrameControl.Version = 0;
	pMgmtHeader->FrameControl.Type = DOT11_FRAME_TYPE_MANAGEMENT;
	pMgmtHeader->FrameControl.Subtype =  subtype;

	//firmware can handle rest of framecontrol
	pMgmtHeader->FrameControl.ToDS = 0;
	pMgmtHeader->FrameControl.FromDS = 0;
	pMgmtHeader->FrameControl.MoreFrag = 0;
	pMgmtHeader->FrameControl.Retry = 0;
	pMgmtHeader->FrameControl.PwrMgt = 0;
	pMgmtHeader->FrameControl.MoreData = 0;
	pMgmtHeader->FrameControl.WEP = 0;
	pMgmtHeader->FrameControl.Order = 0;

	//no specific duration was required to send
	pMgmtHeader->DurationID = 314;

	memcpy(pMgmtHeader->DA, Dest, MAC_ADDR_LEN);
	memcpy(pMgmtHeader->SA, Source, MAC_ADDR_LEN);
	memcpy(pMgmtHeader->BSSID, Bssid, MAC_ADDR_LEN);

	pMgmtHeader->SequenceControl.FragmentNumber = 0;
	pMgmtHeader->SequenceControl.SequenceNumber = 0;

	switch (subtype)
	{
		case DOT11_MGMT_SUBTYPE_PROBE_REQUEST: //0
			packetsize = sizeof(DOT11_MGMT_HEADER ) + sizeof(DOT11_MGMT_SUBTYPE_PROBE_REQUEST) + 1;
			pProbeRequest = (PDOT11_PROBE_REQUEST)((PUCHAR)pMgmtHeader + sizeof(DOT11_MGMT_HEADER ));

			pProbeRequest->ssid.ElementID = 0;  //ssid frame
			pProbeRequest->ssid.Length = 0;

			//the number of rates is up to the user
			pProbeRequest->rateframe.ieheader.ElementID = 1;	//rate frame
			pProbeRequest->rateframe.ieheader.Length = 1;		//1 rate object
			pProbeRequest->rateframe.rate[0] = (USHORT)0x82;       //mandatory, 1mbps


		break;

		default:
		break;
	}


	return pMgmtHeader;

}



void main(int argc, const char* argv[] ) {


  PVOID						pMgmtFrame = NULL;
  ULONG						PacketLength;
  PDOT11_PROBE_REQUEST		pProbeRequest = NULL;
  HANDLE					DeviceHandle;

  UCHAR						BroadCast[MAC_ADDR_LEN] = {0xff,0xff,0xff,0xff,0xff,0xff};
  UCHAR						Source[MAC_ADDR_LEN];

  char currdir [MAX_LEN];
  char installstr[MAX_LEN];

	if(argc > 1){
		GetCurrentDirectory (MAX_LEN, currdir);
		sprintf_s(installstr,MAX_LEN, "netcfg -l  %s\\packet11.inf -c s -i Packet11", currdir);
		//printf("install cmd: %s \n", installstr );

		if(* argv[1] == 'i'){
			system(installstr);
		}

		if(* argv[1] == 'u'){
			system("netcfg -u Packet11");
		}

		if(* argv[1] == 'p'){

			DeviceHandle = OpenHandle(pPacketuioDevice);

			IORequest(DeviceHandle , IOCTL_PACKET11_GET_MAC, NULL, 0, Source, MAC_ADDR_LEN);

			PacketLength = sizeof(DOT11_MGMT_HEADER ) + sizeof(DOT11_PROBE_REQUEST) + 1;

			pMgmtFrame = CreatePacket(DOT11_MGMT_SUBTYPE_PROBE_REQUEST,Source, BroadCast,BroadCast, PacketLength);

			IORequest(DeviceHandle , IOCTL_PACKET11_INSERT_PACKET,  (PUCHAR)pMgmtFrame, PacketLength, NULL, 0);

			CloseHandle(DeviceHandle);

		}

	}

  	if(pMgmtFrame) free(pMgmtFrame);

  return;
}
