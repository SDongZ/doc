		Dewired Packet11 v1.5 beta
		by Ryan Grevious

Disclaimer:
This utility is provided as-is without any express or implied warranty. In no 
event will the author be held liable or responsible for any illegal action[s] 
or damage[s] arising from the use of it.
=============================================================================

Description:
This project contains a network driver and an open source command line application.
The command line application demonstrates how to use the Packet11 service.  
The 802.11 frame is constructed in user mode and sent to the Packet11 device
via DeviceIoControl.  Packet11 allocates the necessary resources and sends
the packet to the wireless miniport adapter.

Requirements:
	Windows Vista
	wireless adapter*

*Tested on Atheros USB WiFi, Intel PCI WiFi link and Realtek 8187. It should work
for all wireless adapters.  Please report any adapter that has problems.


Commandline options:
	packettest [i][u][p]
	i - install the driver
	u - uninstall driver
	p - sends a probe request

Usage:
-Make sure to run the command prompt as administrator

-Install the packet11 driver with packettest or manually*.
	To verify the driver is installed, check the list of installed network 
	components for "802.11 Packet Editor".


Constructing Packets:
Management packets may be constructed any way the developer sees fit so long as
they follow the 802.11 format.

Restrictions:
-No data or control frames.  This may change in future releases.
-No more than two packets may be sent during 1 second intervals.
-Mac source address spoofing is disabled.
-Some chipsets need to be associated in order to send user-defined management 
 packets from Packet11

*Manual Install:
Network and Sharing Center
Manage Network Connections
Right click the adapter and click properties
Click Install -> Service
Have Disk -> Browse to packet11.inf
Click OK for any unsigned dialog warnings


1.5 beta changes:
-User-defined 802.11 packets are originated in 802.11 layer
-Some chipsets such as the rltk 8187 do not need to be associated 
  to send user-defined management packets from Packet11




 