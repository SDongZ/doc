#include "wifiscan.h"
int bwait=1;
//print IE
void FuncWlanIEPrint(BYTE IEID ,BYTE IELEN,PBYTE pBeaconframe)
{
printf("######## FuncWlanIEPrint--->########  \n \n");
	printf("IE ElementID:=%d \n",IEID);
	printf("IE Information Length:=%d \n \n",IELEN);
	
	printf("******IE Information Feild***** \n");
	for(int i=0;i<IELEN;i++)
	{
		printf("%d\t",pBeaconframe[i]);
		if((i!=0)&&(i%10)==0)
		printf("\n");
	}
	printf("\n");
	printf("******IE Information Feild***** \n \n");
	//printf("\n \n");
printf("######## FuncWlanIEPrint<--- ######## \n \n");
}


//ies parsing
void FuncWlanParseIEs(PBYTE pBeaconframe,int SizeData)
{
	int len=SizeData;

	printf("######## FuncWlanParseIEs--->########  \n \n");
	while(len>=2) //minimum length for ID and Length field
	{
	
      BYTE IEID;
	  BYTE IELEN;
	  IEID=*pBeaconframe++;
	  IELEN=*pBeaconframe++;
	  len-=2;
	
	   if(IELEN>len)
	   {
		   printf("######## FuncWlanParseIEs IELEN>len =%d =%d<--- ######## \n \n",IELEN,len);
		   return;
	   }

	   switch(IEID)
	   {
		   case IEID_INTERWORKING:
					printf("IEID_INTERWORKING---> \n");
					FuncWlanIEPrint(IEID,IELEN,pBeaconframe);
					printf("IEID_INTERWORKING<--- \n");	
					break;
		   case IEID_ADVPROTOCOL:
		   			printf("IEID_ADVPROTOCOL---> \n");
					FuncWlanIEPrint(IEID,IELEN,pBeaconframe);
					printf("IEID_ADVPROTOCOL<---  \n");
					break;	   	
		   case IEID_EXPBANDREQ:
		   			printf("IEID_EXPBANDREQ---> \n");
					FuncWlanIEPrint(IEID,IELEN,pBeaconframe);
					printf("IEID_EXPBANDREQ<---  \n");
					break;	   
		   case IEID_QOSMAPSET:
		   			printf("IEID_QOSMAPSET---> \n");
					FuncWlanIEPrint(IEID,IELEN,pBeaconframe);
					printf("IEID_QOSMAPSET<---  \n");
					break;	   
		   case IEID_ROAMCONS:
		   			printf("IEID_ROAMCONS---> \n");
					FuncWlanIEPrint(IEID,IELEN,pBeaconframe);
					printf("IEID_ROAMCONS<--- \n");
					break;	
		   case IEID_EMERALERTID:
		   			printf("IEID_EMERALERTID---> \n");
					FuncWlanIEPrint(IEID,IELEN,pBeaconframe);
					printf("IEID_EMERALERTID<---  \n");
					break;
		   case	IEID_VENDORSPEC:
		   			printf("IEID_VENDORSPEC---> \n");
					FuncWlanIEPrint(IEID,IELEN,pBeaconframe);
					printf("IEID_VENDORSPEC<---  \n");
					break;
		   default:
					   printf("default IE---> \n");
					   FuncWlanIEPrint(IEID,IELEN,pBeaconframe);
					   printf("default IE<--- \n");
					   break;

	   }
			printf("\n");
			len-=IELEN;
			pBeaconframe+=IELEN;
			

	}
	printf("######## FuncWlanParseIEs <---########  \n \n");
}


//trying to print beacon or probe resp IE RAW data
DWORD FuncWlanBeaconFrame(PWLAN_BSS_ENTRY pWlanBssEntry,PBYTE pBeaconframe)
{

	PBYTE pBlob=NULL;
	ULONG i=0;

	printf("######## FuncWlanBeaconFrame--->######## \n \n");
	printf("offset of IE data blob =%d \n",pWlanBssEntry->ulIeOffset);
	printf("Size of IE data blob =%d \n",pWlanBssEntry->ulIeSize);
	printf("MAC ADRESS for AP  %02x:%02x:%02x:%02x:%02x:%02x\n",	pWlanBssEntry->dot11Bssid[0],
																	pWlanBssEntry->dot11Bssid[1],
																	pWlanBssEntry->dot11Bssid[2],
																	pWlanBssEntry->dot11Bssid[3],
																	pWlanBssEntry->dot11Bssid[4],
																	pWlanBssEntry->dot11Bssid[5]);
	printf("BSS Type %d \n ",pWlanBssEntry->dot11BssType);
	printf("SSID %s \n ",pWlanBssEntry->dot11Ssid.ucSSID);
	printf("Capability of beacon %d  \n \n ",pWlanBssEntry->usCapabilityInformation);
	//moving pointer the correct offset
	pBlob=(PBYTE)(pWlanBssEntry)+pWlanBssEntry->ulIeOffset;
	//IE data size
	memcpy((void*)pBeaconframe,(void*)pBlob,pWlanBssEntry->ulIeSize);
    printf("*****Total IE data byte by byte Last Beacon and Probe Response****** \n");
	do
	{
		printf("%d\t",pBeaconframe[i]);
		i++;
		if((i!=0)&&(i%10)==0)
		printf("\n");

	}while(i<pWlanBssEntry->ulIeSize);
	printf("\n");
	 printf("*****Total IE data byte by byte Last Beacon and Probe Response****** \n \n");
	//printf("\n \n");
	FuncWlanParseIEs(&pBeaconframe[0],pWlanBssEntry->ulIeSize);

	printf("######## FuncWlanBeaconFrame <---########  \n \n");
	return 0;
}



// to check the operating system to meention the type of client (vista,xp etc)
bool IsVistaOrHigher()  

{  
	OSVERSIONINFO osVersion; 
	ZeroMemory(&osVersion, sizeof(OSVERSIONINFO));  
	osVersion.dwOSVersionInfoSize = sizeof(OSVERSIONINFO);  
	printf("######## IsVistaOrHigher--->########  \n \n");
		if(!GetVersionEx(&osVersion))  
		{
			printf("######## IsVistaOrHigher<--- ######## \n \n");
			return false; 
		}
		if(osVersion.dwMajorVersion >= 6)
		{
			printf("######## IsVistaOrHigher<--- ######## \n \n");
			return true;
		}
	
printf("######## IsVistaOrHigher<---########  \n \n");
		return false;  

} 
//function that will for getting nw list
void FuncWlanGetNWList()
{

	
	printf("######## FuncWlanGetNWList--->######## \n\n");
    hResult = WlanGetAvailableNetworkList(phClientHandle, 
										  &guidInterface,
										  NULL, 
										  NULL, 
										  &pBssList);   
	if(hResult!= ERROR_SUCCESS)
	{
		printf("Failed WlanGetAvailableNetworkList %d \n ",hResult);
		printf("######## FuncWlanGetNWList<--- ######## \n");
		return;
	}
	printf("total no of Items in Nw list =%d \n",pBssList->dwNumberOfItems);
	if(pBssList->dwNumberOfItems==0)
	{
		printf("######## FuncWlanGetNWList is Empty<--- ######## \n \n");
		return;
	}
	for(unsigned int i=0;i<pBssList->dwNumberOfItems;i++)
	{
		printf("******* Bss network List******* \n");
		printf("NW profile name %s \n",pBssList->Network[i].strProfileName);
		printf("NW SSID %s \n",pBssList->Network[i].dot11Ssid.ucSSID);
		printf("NW SSID Length %d \n",pBssList->Network[i].dot11Ssid.uSSIDLength);
		printf("NW no of BSSIDS %d  \n",pBssList->Network[i].uNumberOfBssids);
		//printf("\n \n");

		//bss type
		switch(pBssList->Network[i].dot11BssType)
		{
			case dot11_BSS_type_infrastructure:
				printf("BSS TYPE: dot11_BSS_type_infrastructure \n");
					break;
					
			case dot11_BSS_type_independent:
					printf("BSS TYPE: dot11_BSS_type_independent \n");
					break;

			case dot11_BSS_type_any:
					printf("BSS TYPE: dot11_BSS_type_independent \n");
					break;
			
			default:
				printf("unknown bss type %d \n", pBssList->Network[i].dot11BssType);
				break;
		}
	

		// Auth type 
		switch(pBssList->Network[i].dot11DefaultAuthAlgorithm)
		{
			case DOT11_AUTH_ALGO_80211_OPEN:
					printf("Auth type: DOT11_AUTH_ALGO_80211_OPEN \n");
					break;
					
			case DOT11_AUTH_ALGO_80211_SHARED_KEY:
					printf("Auth type: DOT11_AUTH_ALGO_80211_SHARED_KEY \n");
					break;

			case DOT11_AUTH_ALGO_WPA:
					printf("Auth type: DOT11_AUTH_ALGO_WPA \n");
					break;
			case DOT11_AUTH_ALGO_WPA_PSK:
					printf("Auth type: DOT11_AUTH_ALGO_WPA_PSK \n");
					break;
			case DOT11_AUTH_ALGO_WPA_NONE:
					printf("Auth type: DOT11_AUTH_ALGO_WPA_NONE \n");
					break;
			case DOT11_AUTH_ALGO_RSNA:
					printf("Auth type: DOT11_AUTH_ALGO_RSNA \n");
					break;
			case DOT11_AUTH_ALGO_RSNA_PSK:
					printf("Auth type: DOT11_AUTH_ALGO_RSNA_PSK \n");
					break;
			case DOT11_AUTH_ALGO_IHV_START:
					printf("Auth type: DOT11_AUTH_ALGO_IHV_START \n");
					break;
			case DOT11_AUTH_ALGO_IHV_END:
					printf("Auth type: DOT11_AUTH_ALGO_IHV_END \n");
					break;
			
			default:
				printf("unknown Auth type %d  \n",pBssList->Network[i].dot11DefaultAuthAlgorithm);
				break;
		}
		printf("\n \n");
	}
	
	printf("######## FuncWlanGetNWList<--- ######## \n \n");
}
// function for bss list where we can read beacon with pointer to strcuture offset and length of response
void FuncWlanGetBSSList()
{

	printf("######## FuncWlanGetBSSList--->########  \n \n");
	hResult = WlanGetNetworkBssList(phClientHandle, 
									&guidInterface,
									NULL, 
								    dot11_BSS_type_any,
									NULL,
									NULL,
									&pWlanBssList);   
	if(hResult!= ERROR_SUCCESS)
	{
		printf("Failed WlanGetNetworkBssList  %d \n ",hResult);
		printf("########FuncWlanGetBSSList<---######## \n \n");
		return;
	}
		printf("no of memebers in bss list entry=%d  \n ",pWlanBssList->dwNumberOfItems);
		printf("total size of the structure =%d  \n",pWlanBssList->dwTotalSize);
		
	if(pWlanBssList->dwNumberOfItems==0)
	{
		printf("########FuncWlanGetBSSList is empty<---######## \n \n");
		return;
	}

	for(unsigned int i=0;i<pWlanBssList->dwNumberOfItems;i++)
	{
		 
		PWLAN_BSS_ENTRY pWlanBssEntry=&pWlanBssList->wlanBssEntries[i];
		void *beaconframe=malloc(pWlanBssEntry->ulIeSize);
		FuncWlanBeaconFrame(pWlanBssEntry,(PBYTE)beaconframe);

	}


printf("########FuncWlanGetBSSList<---######## \n \n");

}


//thread created and running for event to be happen
DWORD WINAPI FuncWlanThread(LPVOID lpParameter)
{
	UNREFERENCED_PARAMETER(lpParameter);
	DWORD WaitResult;
	printf("######## FuncWlanThread---> \n\n");
	printf("Thread %d waiting for wait event\n", GetCurrentThreadId());

	WaitResult = WaitForSingleObject(EventWait,INFINITE);   

        switch (WaitResult) 
			{
				// Event object was signaled
				case WAIT_OBJECT_0: 
						printf("Thread %d event signaled\n",GetCurrentThreadId());
						//Un registering the wlan notification for scan as scan is completed
						hResult=WlanRegisterNotification(phClientHandle,
														WLAN_NOTIFICATION_SOURCE_NONE,
														TRUE,
														NULL,
														NULL,
														NULL,
														&pdwPrevNotifSource);
						
						if(hResult!=ERROR_SUCCESS)
							{
								printf("failed Wlan UnRegisterNotification=%d \n",hResult);
								printf("######## FuncWlanThread<---######## \n \n");
								return hResult;
							}
						else
						{
							FuncWlanGetNWList(); ///WORKING FINE
							FuncWlanGetBSSList();//working fine
						}
						
					break; 
				// An error occurred
				default: 
					printf("Wait error (%dn \n", GetLastError()); 
					printf("######## FuncWlanThread<---######## \n \n");
					return 0; 
			}
	printf("######## FuncWlanThread<---######## \n \n");
	bwait=0;
	return 1;
}
//function that creates thread and events and wait for unregistering the CB
int FuncWlanCreateThreadsAndEvents()
{

    printf("######## FuncWlanCreateThreadsAndEvents---> ######## \n \n");
	EventWait=CreateEvent(NULL,
						  FALSE,
						  FALSE,
						  "WaitEvent");
	    if (EventWait == NULL) 
			{ 
				printf("CreateEvent failed (%d)\n", GetLastError());
				printf("######## FuncWlanCreateThreadsAndEvents<---######## \n \n");
				return -1;
			}
	EventThread=CreateThread(NULL,
							 0,
							 FuncWlanThread,
							 NULL,
							 0,
							 0);
		if (EventThread == NULL) 
		{ 
			printf("CreateThread failed (%d)\n", GetLastError());
			printf("######## FuncWlanCreateThreadsAndEvents<---######## \n \n");
			return -1;
		}
	
	printf("######## FuncWlanCreateThreadsAndEvents<---######## \n \n");
	return 1;
}



//wlan ACM notify function pointer for scan complete
void FuncWlanAcmNotify(PWLAN_NOTIFICATION_DATA data,PVOID context)
{
	printf("######## FuncWlanAcmNotify--->######## \n\n");
	if(data->NotificationCode==wlan_notification_acm_scan_complete)
	{
		printf("Scan is completed with success  \n");
		if(!SetEvent(EventWait))
			printf("setting event failed \n");
	}

	if(data->NotificationCode==wlan_notification_acm_scan_fail)
	{
		printf("Scan is completed with Fail  \n");
		if(!SetEvent(EventWait))
			printf(" setting event failed  \n");
	}

	printf("######## FuncWlanAcmNotify<---######## \n \n");
	
}



//function to open and enumerate
int FuncWlanOpenAndEnum()
{
	DWORD dwClientVersion=(IsVistaOrHigher() ? 2 : 1);

	printf("######## FuncWlanOpenAndEnum--->######## \n\n");
	//creating session handle for the client to connect to server.
	hResult=WlanOpenHandle(dwClientVersion,NULL,&pdwNegotiatedVersion,&phClientHandle);
		if(hResult!=ERROR_SUCCESS)
			{
				printf("failed WlanOpenHandle=%d \n",hResult);
				return hResult;
			}
			else
				{
					printf("WlanOpenHandle is success=%d \n",hResult);
				
				}

	//Enumerates all the wifi adapters currently enabled on PC.
	//Returns the list of interface list that are enabled on PC.
	hResult=WlanEnumInterfaces(phClientHandle,NULL,&pIfList);
			if(hResult!=ERROR_SUCCESS)
				{
					printf("failed WlanEnumInterfaces check adapter is on=%d \n",hResult);
					return hResult;
				}
			else
				{
					printf("WlanEnumInterfaces is success=%d \n",hResult);
				
				}
	
	printf("######## FuncWlanOpenAndEnum<---######## \n \n");
	return hResult;
}

//function prints the all the wlan interfaces present on pc and storing first GUID assuming only one adapter
void FuncWlanPrintInterfaceNames()
{
	WCHAR SGuid[256]={0};

	printf("######## FuncWlanPrintInterfaceNames--->######## \n\n");

	for(unsigned int i=0;(i < pIfList->dwNumberOfItems);i++)
	{
		printf("WIFI Adapter Description =%ws \n",pIfList->InterfaceInfo[pIfList->dwIndex].strInterfaceDescription);
		StringFromGUID2(pIfList->InterfaceInfo[pIfList->dwIndex].InterfaceGuid,SGuid,256);
		printf("WIFI Adapter GUID=%ws \n",SGuid);

	}
	
	//assuming PC has only one wifi card
	guidInterface=pIfList->InterfaceInfo[0].InterfaceGuid;

	printf("######## FuncWlanPrintInterfaceNames<---######## \n \n");
}

//planning to start scan operation

int FuncWlanScan(int ScanWithIE)
{
		pInterworkingIE pInfoElem	=NULL;
		PWLAN_RAW_DATA	pIeData		=NULL;
		PBYTE			pData		=NULL;
	printf("######## FuncWlanScan--->######## \n\n");
	hResult=WlanRegisterNotification(phClientHandle,
									WLAN_NOTIFICATION_SOURCE_ACM,
									TRUE,
									(WLAN_NOTIFICATION_CALLBACK)FuncWlanAcmNotify,
									NULL,
									NULL,
									&pdwPrevNotifSource);
	if(hResult!=ERROR_SUCCESS)
		{
			printf("failed WlanRegisterNotification=%d \n",hResult);
			printf("######## FuncWlanScan<---######## \n \n");
			return hResult;
		}
	else
	{
		printf("WlanRegisterNotification is success=%d \n",hResult);
	
	}
	//creating threads and events
	hResult=FuncWlanCreateThreadsAndEvents();
	if(hResult==-1)	
		{
			printf("failed FuncWlanCreateThreadsAndEvents=%d \n",hResult);
			printf("######## FuncWlanScan<---######## \n \n");
			return hResult;
		}


	if(ScanWithIE)
	{
		printf("scan with IE \n");

		pIeData=(PWLAN_RAW_DATA)malloc(sizeof(InterworkingIE)+sizeof(DWORD)); 
		memset((void*)pIeData,0,(sizeof(InterworkingIE)+sizeof(DWORD)));		

		pIeData->dwDataSize=sizeof(InterworkingIE);
		pInfoElem =(pInterworkingIE)&pIeData->DataBlob;

		//working only with vvendor specific IE's for 
		//WIFI Adapter Description =Intel(R) Centrino(R) Advanced-N 6205 
		//WIFI Adapter GUID={0E7CAA2C-B007-4B75-A5BF-2B3ED571C635} 
		//May be intel driver filtering reserved element IDS(52-126)
		
		pInfoElem->ElementID=IEID_INTERWORKING; 	
		pInfoElem->Length=sizeof(InterworkingIE)-2;
		pInfoElem->ANO=1;
		//memcpy((void*)&pInfoElem->TEST,(void*)"INTERWORKING",13);
		
	
		hResult=WlanScan(phClientHandle,&guidInterface,NULL,pIeData,NULL);
		
		if(hResult!=ERROR_SUCCESS)
			{
				printf("failed WlanScan check adapter is enabled=%d \n ",hResult);
				if(!SetEvent(EventWait))
				{
					printf("setting event failed \n");
					printf("######## FuncWlanScan<---######## \n \n");
					return hResult;
				}

			}
			else
				{
					printf("WlanScan with IE is success=%d \n",hResult);
				
				}
	}
	else
	{
		printf("scan with out IE \n");
		//wlan scan without mentioning SSID. assuming PC has only one wifi card
		hResult=WlanScan(phClientHandle,&guidInterface,NULL,NULL,NULL);
		if(hResult!=ERROR_SUCCESS)
			{
				printf("failed WlanScan check adapter is enabled=%d \n ",hResult);
				if(!SetEvent(EventWait))
				{
					printf("setting event failed \n");
					printf("######## FuncWlanScan<---######## \n \n");
					return hResult;
				}
			}
		else
			{
				printf("WlanScan with out IE is success=%d \n",hResult);
			
			}
	
	}
	printf("######## FuncWlanScan<---######## \n \n");
	return hResult;
}


int main(int argc, char *argv[])
{
	BOOL ScanWithIE=2;
	printf("######## MAIN()--->######## \n\n");
	if(argc>=2)
	{
		char *str=argv[1];

		if(str[0]=='I')
		{
			ScanWithIE=1;
		}
		else if(str[0]=='N')
		{
			ScanWithIE=0;
		}
		else
		{
			printf(" Enter correct command line argument  \n");
			printf(" EXAMPLE: wifiscan.exe I ---> for adding IE into probe request  \n");
			printf(" EXAMPLE: wifiscan.exe N ---> for not adding IE into probe request  \n \n");
			printf("######## MAIN()<---######## \n");
			return -1;
		
		}
	}
	else
	{
			printf(" Enter correct command line argument  \n");
			printf(" EXAMPLE: wifiscan.exe I ---> for adding IE into probe request  \n");
			printf(" EXAMPLE: wifiscan.exe N ---> for not adding IE into probe request  \n \n");
			printf("######## MAIN()<---######## \n");
			return -1;
	
	
	}
	
//openin handle for client to communicate with adapter and enumerating the wifi interfaces
	hResult=FuncWlanOpenAndEnum();
	if(hResult!=ERROR_SUCCESS)
		{
			printf("######## failed FuncWlanOpenAndEnum=%d  \n",hResult);
			printf("######## MAIN()<---######## \n");
			WlanCloseHandle(phClientHandle,NULL);
			return hResult;
		}
	
// trying to print all the wifi interfaces present and storing GUID for first adapter
	FuncWlanPrintInterfaceNames();

	if(ScanWithIE==1)
	{
		hResult=FuncWlanScan(ScanWithIE);
		if(hResult!=ERROR_SUCCESS)
		{
			printf("failed FuncWlanScan with IE=%d \n",hResult);
			printf("######## MAIN()<---######## \n");
			WlanCloseHandle(phClientHandle,NULL);
			WlanFreeMemory(pIfList);
			CloseHandle(EventWait);
			return hResult;
		}
	}
	else if(ScanWithIE==0)
	{
	    hResult=FuncWlanScan(ScanWithIE);
		if(hResult!=ERROR_SUCCESS)
		{
			printf("failed FuncWlanScan without IE=%d \n",hResult);
			printf("######## MAIN()<---######## \n");
			WlanCloseHandle(phClientHandle,NULL);
			WlanFreeMemory(pIfList);
			CloseHandle(EventWait);
			return hResult;
		}
	}

    while(bwait)
	{
		Sleep(1000);
	}

	WlanFreeMemory(pIfList);
	WlanFreeMemory(pBssList);
	WlanCloseHandle(phClientHandle,NULL);

	printf("######## MAIN()<---######## \n");
	return 0;
}