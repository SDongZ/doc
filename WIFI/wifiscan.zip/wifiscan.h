//Headers for WLAN SCAN
#include <windows.h>
#include <conio.h>
#include <atlbase.h>
#include <wlanapi.h>
#include <WinBase.h>
#include <malloc.h>

// Lib paths
#pragma comment(lib, "wlanapi.lib")
#pragma comment(lib, "ole32.lib")

//variables used for WlanEnumInterfaces 
	PWLAN_INTERFACE_INFO_LIST	pIfList = NULL;
	PWLAN_INTERFACE_INFO		pIfInfo = NULL;
//variables used for WlanGetAvailableNetworkList
	PWLAN_AVAILABLE_NETWORK_LIST	pBssList = NULL;
    PWLAN_AVAILABLE_NETWORK			pBssEntry = NULL;
//VARIABLE USED FOR 
	 PWLAN_BSS_LIST					pWlanBssList=NULL;
	


// Variables for open handle
	DWORD pdwNegotiatedVersion	=0;
	HANDLE phClientHandle		=NULL;
	DWORD hResult				=ERROR_SUCCESS;
	DWORD pdwPrevNotifSource	= 0;

// GUID Variable
	GUID guidInterface			={0};

//Handles for events and threads
	HANDLE EventThread;
	HANDLE EventWait;
#define ETH_LEN 6
// Structure for Interworking element
	typedef struct _Interworking
	{
		BYTE ElementID;
		BYTE Length;
		//BYTE OUI[3];
		//BYTE TEST[50];
		BYTE ANO;      //Access Network Options
		BYTE VenueInfo[2];
		BYTE HESSID[ETH_LEN];
	
	}InterworkingIE,*pInterworkingIE;

	// general IE
	typedef struct _IE
	{
		UCHAR ElementID;
		UCHAR Length;
		UCHAR Data[ETH_LEN];

	}IES,*pIES;

	typedef struct _IeDataq
	{
		BYTE			InterIE[sizeof(InterworkingIE)];
		WLAN_RAW_DATA	pWRD;
		
	}IeDataq,*pIeDataq;



	// Information elements
#define IEID_INTERWORKING 107
#define IEID_ADVPROTOCOL  108
#define IEID_EXPBANDREQ   109
#define IEID_QOSMAPSET    110
#define IEID_ROAMCONS     111
#define IEID_EMERALERTID  112 
#define IEID_VENDORSPEC	  221	